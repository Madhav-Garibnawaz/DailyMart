<?php
$date=date('d/m/Y');
echo $date;
?>