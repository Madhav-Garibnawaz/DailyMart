<?php

    $con = mysqli_connect("localhost","root","","project") or die("Connection not established");

?>