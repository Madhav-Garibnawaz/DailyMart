<?php

    session_start();
    echo "<h1>Welcome Back!</h1>";
    echo "<h1>" . $_SESSION['aid'];
?>

<?php
    include('hhh2.php');
?>